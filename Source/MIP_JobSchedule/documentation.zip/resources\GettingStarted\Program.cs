﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GettingStarted
{
    using System.Configuration;

    using OPTANO.Modeling.Common;
    using OPTANO.Modeling.Optimization;
    using OPTANO.Modeling.Optimization.Configuration;
    using OPTANO.Modeling.Optimization.Enums;
    using OPTANO.Modeling.Optimization.Solver.Gurobi651;

    /// <summary>
    /// Demo program solving a network design problem
    /// </summary>
    class Program
    {
        /// <summary>
        /// The main method
        /// </summary>
        /// <param name="args">
        /// no arguments required
        /// </param>
        static void Main(string[] args)
        {

            Node pb = new Node("Paderborn", 50);
            Node ny = new Node("New York", -100);
            Node b = new Node("Beijing", 50);
            Node sp = new Node("São Paulo", 50);
            Node sf = new Node("San Francisco", -50);
            var nodes = new List<Node> { pb, ny, b, sp, sf };

            var edges = new List<Edge>
                            {
                                new Edge(pb, ny, null, 3, 1000),
                                new Edge(ny, b, null, 2, 1000),
                                new Edge(b, sp, 75, 1, 1000),
                                new Edge(sp, sf, null, 4, 1000),
                                new Edge(pb, sp, null, 5, 1000),
                                new Edge(b, pb, 50, 1, 1000)
                            };

            // take configr
            var scopeSettings = OptimizationConfigSection.Instance ?? new OptimizationConfigSection();

            // Access all fields avaialbe via xml-section. 
            scopeSettings.ModelElement.EnableFullNames = true;
            scopeSettings.ModelElement.ComputeRemovedVariables = true;
            scopeSettings.ModelElement.ModelBehavior = ModelBehavior.Auto.ToString();

            using (var scope = new ModelScope(scopeSettings))
            {
                // For demonstration only: ModelBehavior might be changed at any time during model generation. Some other config values might not. 
                scope.ModelBehavior = ModelBehavior.Auto;

                // create a model, based on given data and the modelscope
                var designModel = new NetworkDesignModel(nodes, edges);
                
                // Get a solver instance, change your solver
                var solver = new GurobiSolver();

                // solve the model
                var solution = solver.Solve(designModel.Model);
                
                // import the results back into the model 
                designModel.Model.VariableCollections.ForEach(vc => vc.SetVariableValues(solution.VariableValues));

                // print objective and variable decisions
                Console.WriteLine($"{solution.ObjectiveValues.Single()}");
                designModel.x.Variables.ForEach(x => Console.WriteLine($"{x.ToString().PadRight(36)}: {x.Value}"));
                designModel.y.Variables.ForEach(y => Console.WriteLine($"{y.ToString().PadRight(36)}: {y.Value}"));

                designModel.Model.VariableStatistics.WriteCSV(AppDomain.CurrentDomain.BaseDirectory);
            }


        }
    }
}
